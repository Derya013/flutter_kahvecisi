import 'package:flutter/material.dart';

// Uygulamanın ana fonksiyonu
void main() {
  // Uygulama, BenimUyg widget'ı ile başlatılır
  runApp(
    BenimUyg(), // Uygulamanın başlangıç widget'ı
  );
}

// BenimUyg adında bir StatelessWidget oluşturuluyor
class BenimUyg extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Uygulamanın genel tasarımını ayarlamak için kullanılır
      // Burada tema ayarı yapılabilir; örneğin: theme: ThemeData(fontFamily: 'Satisfy'),
      home: Scaffold(
        // Scaffold, uygulamanın temel görsel yapısını sağlar
        backgroundColor: Colors.brown[700], // Arka plan rengi
        body: SafeArea(
          // Ekranın güvenli alanına yerleştirir; cihazın kesik köşeleri veya duraklamalarından etkilenmez
          child: Center(
            // Merkezde yerleştirilmiş widget'ları içerir
            child: Column(
              mainAxisSize: MainAxisSize
                  .min, // Column yüksekliği, içindeki elemanların minimum yüksekliğine göre ayarlanır
              children: [
                // Daire şeklindeki profil resmi
                CircleAvatar(
                  radius: 70.0, // Dairenin yarıçapı
                  backgroundColor: Colors.lime, // Daire arka plan rengi
                  backgroundImage:
                      AssetImage('assets/images/kahve.jpeg'), // Profil resmi
                ),
                // Uygulamanın başlığı
                Text(
                  'Flutter Kahvecisi', // Başlık metni
                  style: TextStyle(
                    fontFamily: 'Satisfy', // Yazı tipi
                    fontSize: 45, // Yazı boyutu
                    color: Colors.brown[100], // Yazı rengi
                  ),
                ),
                // Alt başlık
                Text(
                  'BİR FİNCAN UZAĞINIZDA', // Alt başlık metni
                  style: TextStyle(
                    fontSize: 16, // Yazı boyutu
                    color: Colors.white, // Yazı rengi
                  ),
                ),
                // İki widget arasında boşluk bırakmak için Divider
                Container(
                  width: 200, // Divider'ın genişliği
                  child: Divider(
                    height: 30, // Divider yüksekliği
                    color: Colors.brown[900], // Divider rengi
                  ),
                ),
                // Email adresini göstermek için Card widget'ı
                Card(
                  margin: EdgeInsets.symmetric(
                      horizontal: 45.0), // Kartın yanlardan olan boşlukları
                  color: Colors.brown[900], // Kart arka plan rengi
                  child: Padding(
                    padding:
                        const EdgeInsets.all(8.0), // Kartın içindeki padding
                    child: ListTile(
                      leading: Icon(
                        Icons.email, // Email ikonu
                        color: Colors.white, // İkon rengi
                      ),
                      title: Text(
                        'siparis@fkahvecisi.com', // Email adresi
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20.0), // Yazı rengi ve boyutu
                      ),
                    ),
                  ),
                ),
                // İki Card widget'ı arasında boşluk bırakmak için SizedBox
                SizedBox(
                  height: 10.0, // Boşluk yüksekliği
                ),
                // Telefon numarasını göstermek için başka bir Card widget'ı
                Card(
                  margin: EdgeInsets.symmetric(
                      horizontal: 45.0), // Kartın yanlardan olan boşlukları
                  color: Colors.brown[900], // Kart arka plan rengi
                  child: ListTile(
                    leading: Icon(
                      Icons.phone, // Telefon ikonu
                      color: Colors.white, // İkon rengi
                    ),
                    title: Text(
                      '0555 555 55 55', // Telefon numarası
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20.0), // Yazı rengi ve boyutu
                    ),
                  ),
                ),
              ], // Çocuk widget'ların kapanışı
            ),
          ),
        ),
      ),
    );
  }
}
