package com.example.flutter_kahvecisi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
